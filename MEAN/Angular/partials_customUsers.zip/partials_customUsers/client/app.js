var myApp = angular.module('myApp', ['ngRoute']);

    //  use the config method to set up routing:
    myApp.config(function ($routeProvider) {
      $routeProvider
        .when('/',{
            templateUrl: 'partials/customizeUsers.html',
            controller: 'userController'
        })
        .when('/showUsers',{
            templateUrl: 'partials/userList.html',
            // controller: viewController
        })
        .otherwise({
          redirectTo: '/'
        });
    
    });

// CONTROLLERS

 myApp.controller('userController', ['$scope', 'userFactory', function($scope, userFactory){
    function setUsers(data){
        $scope.users = data;
        $scope.user = {};
    }
     $scope.createUser = function(){
         console.log('in controller createUser');
         userFactory.index(setProducts);
     }
 }]);


// FACTORY
var app = angular.module('myApp', []);
app.factory('userFactory', ['$http', function($http){
    var factory = {};
    var users = [];

    factory.index = function(callback){
        console.log('in factory index');
        callback(users);
    }

    factory.createUser = function(user, callback){
        console.log("in createUsers");
        users.push(user);
        callback(users);
    }


}]);
