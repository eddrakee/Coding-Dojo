-- MySQL Workbench Forward Engineering
DELETE FROM users

