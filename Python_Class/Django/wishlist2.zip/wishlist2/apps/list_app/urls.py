from django.conf.urls import url, include
from . import views


urlpatterns =[
    url(r'^dashboard$', views.list_index, name= 'list_index' ),
    url(r'^create$', views.add_item, name= 'add' ),
    url(r'^create_item$', views.create_item, name= 'create' ),
    url(r'^logout$', views.logout, name= 'logout' ),
  
]