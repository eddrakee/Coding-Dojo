from __future__ import unicode_literals
import bcrypt
import hashlib
import re
from ..login_app.models import User

from django.db import models

# Create your models here.
class ItemManager(models.Manager):
    def get_all_data(self, session_id): #this is coming from list_index
        user_info = User.objects.all()
        item_info = self.all(),
        current_user = User.objects.get_current(session_id)
        wishlist = Item.objects.find_wishlist(session_id)
        other_people_wl = self.other_wishlist(session_id)

        all_data = {
            'user_info' : user_info,
            'item_info' : item_info,
            'current_user' : current_user,
            'wishlist' : wishlist,
            'other_wishlist' : other_people_wl
        }
        print(all_data['current_user'].first_name)
        return all_data

    def make_item(self, postData, session_id):
        current_user_obj = User.objects.get(id=session_id)#session_id is an entire object
        self.create(
        name = postData['item_name'],
        created_by = current_user_obj #this is entering the appropriate fields for the item we created
        )
        new_item_id = self.filter().latest('id')#this will get the item's id that we just created in the lines above
        self.add_wishlist(new_item_id, current_user_obj)
        #new_item_id will be item_id in add_wishlist, same for current_user_obj, it will be user_id. ORDER MATTERS!

    def add_wishlist(self,item_id, user_id):
        # item_obj = self.get(id=item_id)
       item_id.wishlist.add(user_id)#this is the user object from make_item/other places
       #since we are passing in the full item object and user object, we don't need to query for the wishlist. 
       #so it will add to our wishlist entry in our item table
    def find_wishlist(self, session_id):
        return self.filter(wishlist__id=session_id)

    def other_wishlist(self,session_id):
        return self.exclude(wishlist__id=session_id)

class Item(models.Model):
    name = models.CharField(max_length= 100)
    created_by = models.ForeignKey(User, related_name="items_added")
    wishlist = models.ManyToManyField(User, related_name = "wishlist_list")
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = ItemManager()



