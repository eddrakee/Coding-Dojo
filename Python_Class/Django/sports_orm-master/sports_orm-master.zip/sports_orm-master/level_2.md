# ForeignKey Relationships

1. Find all teams in the Atlantic Soccer Conference
2. Find all (current) players on the Boston Penguins
3. Find all (current) players in the International Collegiate Baseball Conference
4. Find all (current) players in the American Conference of Amateur Football with last name "Lopez"
5. Find all football players
6. Find all teams with a (current) player named "Sophia"
7. Find all leagues with a (current) player named "Sophia"
8. Find everyone with the last name "Flores" who DOESN'T (currently) play for the Washington Roughriders
