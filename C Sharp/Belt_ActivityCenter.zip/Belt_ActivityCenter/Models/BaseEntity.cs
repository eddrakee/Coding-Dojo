using System;

namespace UserDash.Models
{
    public abstract class BaseEntity
    {
        
    }
}